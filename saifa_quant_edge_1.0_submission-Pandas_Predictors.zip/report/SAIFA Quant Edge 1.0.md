<style>
@page { size: A4; margin: 0.45in 0.55in; }
body { font-size: 9pt; line-height: 1.08; }
h1 { font-size: 17pt; } h2 { font-size: 13pt; } h3 { font-size: 10.5pt; }
p { margin: 0.26em 0; }
table { font-size: 8.5pt; }
</style>

# SAIFA Quant Edge 1.0
## Risk Across Tails and Timescales
### Wavelet–Copula Analysis of Horizon-Dependent Tail Dependence

**Round 1 Initial Screening Challenge**  
**Submission date:** 7 October 2026  
**Portfolio:** 60% SPY / 30% TLT / 10% GLD

<div style="page-break-after: always;"></div>

---

## 1. Executive Summary

This study asks whether extreme dependence among equity, duration, and gold exposures changes across investment horizons, and whether a horizon-aware wavelet–copula risk model improves unseen-data risk measurement relative to simple benchmarks. The portfolio is economically meaningful because it combines the main growth exposure (SPY), long-duration Treasury exposure (TLT), and a smaller alternative macro/safe-haven allocation (GLD).

Daily adjusted prices from Yahoo Finance are used for 1 January 2012–6 October 2026. The model is estimated on 3,017 training observations through 31 December 2023 and evaluated without refitting on 692 test observations from 1 January 2024–6 October 2026. A level-3 Daubechies-4 stationary wavelet transform separates returns into short, medium, long, and trend components. Within each horizon, rank-based empirical margins and a three-dimensional Gaussian or Student-t copula are fitted; AIC selects the Student-t copula for all four horizons. Tail dependence is estimated pairwise at the 5% lower-tail threshold, and 10,000 simulations produce 99% VaR and ES estimates.

The empirical tail-dependence estimates vary by horizon. For example, SPY–GLD increases from 0.0867 at the short horizon to 0.1800 at the long horizon, while TLT–GLD reaches 0.2600 at the long horizon. This supports horizon-specific dependence analysis rather than a constant-dependence assumption.

However, the current aggregate risk model does not link the wavelet horizons in one joint distribution. It simulates each horizon independently and then adds the simulated components. That assumption creates artificial diversification across frequencies. The resulting Wavelet-Copula 99% VaR is -1.167%, compared with -1.806% for historical simulation; its ES is -1.779%, compared with -2.673% historically. The difference is not evidence of superior risk forecasting. On the fixed out-of-sample test, the Wavelet-Copula threshold is violated 28 times where 6.92 violations are expected, with a Kupiec POF p-value of 1.328e-09. The historical benchmark has 5 violations and a p-value of 0.440.

**Conclusion:** the project supports horizon-specific tail-dependence analysis but rejects naive independent aggregation of horizon-specific simulations as a reliable production risk model. A risk manager should retain historical simulation or a conservative stress framework for primary control, monitor tail dependence by horizon, and require an explicit cross-horizon dependence model before using the proposed approach for capital VaR.

## 2. Research Question and Motivation

Diversification can weaken precisely when it is most needed. During stressed markets, assets that appear diversifying in ordinary conditions may experience stronger joint losses. Ordinary correlation summarizes average linear co-movement; it does not describe the probability that one asset is in its lower tail conditional on another asset already being there. Lower-tail dependence is therefore directly relevant to capital protection and limit setting.

The relevant dependence may also depend on the horizon. A short shock, a multi-day sell-off, and a persistent macroeconomic repricing need not produce the same relationships among equities, duration, and gold. Wavelets provide a way to inspect these timescales separately. The central questions are:

1. What portfolio is being studied, and why is it economically meaningful?
2. Does extreme dependence change across investment horizons?
3. How much risk does a one-horizon or simple dependence model miss?
4. Does the proposed model perform better on unseen data than a simple benchmark?
5. What should a risk manager change because of the result?

The answer to the fourth question is negative for the current implementation: its out-of-sample VaR calibration fails materially.

## 3. Portfolio and Data

### 3.1 Portfolio

| Asset | Weight | Economic role |
|---|---:|---|
| SPY | 60% | U.S. equity growth and the portfolio’s principal risk exposure |
| TLT | 30% | Long-duration U.S. Treasury and duration exposure |
| GLD | 10% | Gold and alternative macro/safe-haven exposure |

The weights are a team design choice, not an official competition rule. The three assets represent distinct but economically connected drivers of portfolio risk: growth, rates, and macro hedging.

### 3.2 Data and returns

Prices are downloaded from Yahoo Finance through `yfinance`, using adjusted close where available, at daily frequency. The full sample is 2012-01-01 to 2026-10-06. Prices are aligned by date, then the current implementation applies forward-fill and backward-fill before calculating returns. Daily simple returns are used for portfolio aggregation; daily log returns are used for modeling:

\[
r_{i,t}=\log(P_{i,t}/P_{i,t-1}).
\]

The time split is strictly chronological:

| Sample | Dates | Observations | Use |
|---|---|---:|---|
| Training | 2012-01-01–2023-12-31 | 3,017 | Estimate transforms, margins, copulas, and risk thresholds |
| Test | 2024-01-01–2026-10-06 | 692 | Fixed-threshold out-of-sample backtest |

Yahoo Finance is a practical public data source, but it is not a controlled institutional data vendor. Historical revisions, corporate-action adjustments, download failures, and timestamp conventions can affect exact values. Forward/backward filling can also introduce observations that were not directly observed; this is a limitation, not a claim of perfect preprocessing.

<img src="../outputs/figures/fig1_cumulative_performance.png" width="300" />

*Figure 1. Cumulative performance of the assets and/or portfolio over the supplied sample. It provides economic context for the instruments but does not validate the tail-risk model.*

## 4. Methodology

The implemented pipeline is:

**prices → returns → train/test split → wavelet decomposition → pseudo-uniform margins → copula fitting → tail-dependence estimation → Monte Carlo simulation → VaR/ES → benchmarks → fixed-threshold OOS backtest.**

All reported training thresholds are estimated without using future test observations. No rolling refit is used in the reported test evaluation.

<img src="../outputs/figures/fig2_return_distributions.png" width="300" />

*Figure 2. Return distributions for the portfolio assets. The figure motivates non-Gaussian dependence modeling but should not be read as a formal distributional test.*

## 5. Wavelet Analysis

The implementation uses PyWavelets `pywt.swt`, a stationary/non-decimated wavelet transform, described by the project as MODWT-style. A Daubechies-4 (`db4`) wavelet is applied at level 3. Symmetric padding is used when the sample length is not compatible with the SWT requirement; the padded portion is removed after reconstruction.

The resulting components are interpreted as:

| Component | Approximate timescale |
|---|---|
| Short (D1) | 2–4 days |
| Medium (D2) | 4–8 days |
| Long (D3) | 8–16 days |
| Trend (A3) | Remaining low-frequency component |

Wavelets are useful here because they preserve time localization while separating fluctuations by scale. They do not, by themselves, establish that the components are economically independent. Boundary effects, the choice of `db4`, the fixed level, and the interpretation of approximate timescales remain sources of model uncertainty.

<img src="../outputs/figures/fig3_wavelet_decomposition.png" width="300" />

*Figure 3. Stationary wavelet decomposition into short, medium, long, and trend components. It shows the objects on which horizon-specific dependence is estimated; it does not demonstrate cross-horizon independence.*

## 6. Copula and Tail-Dependence Methodology

For each horizon, each asset’s component is transformed to a rank-based pseudo-uniform variable. These empirical margins separate marginal behavior from dependence. Gaussian and Student-t copulas are fitted for the three-dimensional SPY/TLT/GLD simulation, and AIC is used for selection. A bivariate Clayton fitting routine exists for pairwise analysis, but Clayton is not used in the final three-dimensional portfolio simulation.

The root output selects the Student-t copula at every horizon:

| Horizon | Selected copula | AIC | BIC |
|---|---|---:|---:|
| Short | Student-t | -747.093 | -723.045 |
| Medium | Student-t | -653.774 | -629.725 |
| Long | Student-t | -766.296 | -742.248 |
| Trend | Student-t | -606.626 | -582.577 |

*Interpretation.* AIC favors the Student-t specification within each horizon in the supplied implementation. This is a model-selection result, not proof that the copula is correctly specified or that it will forecast unseen risk successfully.

Empirical lower-tail dependence is estimated at a 5% threshold as:

\[
\hat\lambda_L = P(U_2<0.05\mid U_1<0.05).
\]

| Asset pair | Short | Medium | Long |
|---|---:|---:|---:|
| SPY–TLT | 0.0533 | 0.0333 | 0.0600 |
| SPY–GLD | 0.0867 | 0.0933 | 0.1800 |
| TLT–GLD | 0.2000 | 0.1733 | 0.2600 |

*Interpretation.* Tail dependence is not constant across the reported horizons. The largest long-horizon values occur for SPY–GLD and TLT–GLD. These are descriptive empirical estimates at one threshold; no formal confidence intervals or hypothesis test for differences across horizons is implemented.

<img src="../outputs/figures/fig4_tail_dependence.png" width="300" />

*Figure 4. Pairwise empirical lower-tail dependence by horizon. It matters because it shows that diversification relationships can differ between short and persistent movements.*

## 7. Portfolio Risk Methodology

Risk is measured at the 99% confidence level using 10,000 Monte Carlo simulations. VaR is the empirical first percentile of simulated portfolio log returns; ES is the mean return at or below that VaR threshold. Simulated uniforms from the selected copula are mapped back to return space using inverse empirical quantiles. Asset returns are converted to simple returns for portfolio weighting and then converted back to a portfolio log return.

Three risk estimates are compared:

- **Historical benchmark:** empirical portfolio risk from the training-period returns.
- **Single-Horizon Copula:** a three-dimensional copula benchmark without wavelet horizon aggregation.
- **Wavelet-Copula:** horizon-specific simulations aggregated into one portfolio distribution.

The crucial qualification is that the project fits a coherent three-asset copula **within each horizon**, but not one coherent joint copula across short, medium, long, and trend components. The horizon simulations are aggregated independently. **We model the three assets jointly within each wavelet horizon, but we do not model dependence between the wavelet horizons themselves. The independent aggregation of horizon simulations can destroy cross-horizon crisis dependence and lead to understated aggregate risk.**

<img src="../outputs/figures/fig5_var_es_comparison.png" width="300" />

*Figure 5. Training-period 99% VaR and ES estimates. The Wavelet-Copula estimates are materially closer to zero than both benchmarks, which is a warning sign when viewed alongside the subsequent backtest.*

## 8. Results

### 8.1 Risk comparison

| Model | 99% VaR | 99% ES |
|---|---:|---:|
| Historical Benchmark | -1.806% | -2.673% |
| Single-Horizon Copula | -1.802% | -2.621% |
| Wavelet-Copula | -1.167% | -1.779% |

*Interpretation.* The Wavelet-Copula VaR is approximately 35% less conservative in magnitude than historical VaR, and its ES is also less negative. The result is consistent with artificial diversification created by independent horizon aggregation; it is not evidence that the model has found a safer true tail distribution.

### 8.2 Fixed-threshold out-of-sample validation

The 692 test observations are evaluated using thresholds fixed at the 31 December 2023 training cutoff. At a 99% level, 6.92 violations are expected.

| Model | Violations | Expected | Kupiec POF p-value | ES score (actual − forecast) |
|---|---:|---:|---:|---:|
| Historical Benchmark | 5 | 6.92 | 0.440 | -0.00155 |
| Wavelet-Copula | 28 | 6.92 | 1.328e-09 | 0.00097 |

*Interpretation.* The historical benchmark’s violation count is close to the nominal expectation and its Kupiec test does not reject unconditional coverage at conventional levels. The Wavelet-Copula produces four times as many violations as expected and is rejected by the Kupiec POF test. The ES score is a simplified severity comparison, not a formal Acerbi–Szekely test.

<img src="../outputs/figures/fig6_oos_violations.png" width="300" />

*Figure 6. Fixed Wavelet-Copula VaR threshold and realized test-period violations. The concentration of violations demonstrates the practical consequence of the optimistic training-period threshold.*

## 9. Benchmark and Out-of-Sample Validation

Historical simulation is a fair baseline because it makes relatively few parametric assumptions and directly reflects the empirical loss distribution available in the training sample. The single-horizon copula provides a more structured dependence benchmark while retaining one time scale. The proposed model adds horizon decomposition but also adds the independent aggregation assumption.

The OOS design is deliberately simple and strict: parameters and thresholds are fixed at the training cutoff, and no test information is used for refitting. This makes the comparison a calibration test under changing conditions, not a claim that a static forecast would be used forever in production.

The reported validation is incomplete by design. The project does not implement a Christoffersen conditional-coverage test, a formal Acerbi–Szekely ES test, bootstrap confidence intervals, rolling estimation, or a formal test of differences in tail dependence across horizons. The Kupiec result therefore addresses unconditional violation frequency only.

## 10. What Happens When Horizon Dependence Is Ignored?

The single-horizon and historical estimates are similar: VaR is -1.802% and -1.806%, respectively, while ES is -2.621% and -2.673%. The Wavelet-Copula is much less negative: VaR is -1.167% and ES is -1.779%. In the test sample, that optimistic threshold generates 28 violations instead of approximately 6.92.

The economic interpretation is not that wavelets are unhelpful. Rather, horizon-specific dependence is being analyzed correctly only within each component. The aggregate simulation then treats the components as independent. During a crisis, short, medium, long, and trend movements can reinforce one another. Independent draws can spread losses across separate simulated horizons and create diversification that is not present in a joint crisis episode. The resulting underestimation is visible both in the training-period risk comparison and in the OOS violation count.

## 11. Risk-Manager Recommendation

1. **Do not use the current independent-horizon Wavelet-Copula model as the primary capital VaR model.** Its OOS calibration failure is too material.
2. **Use historical simulation or a conservative stress framework for primary control** until the aggregation problem is resolved.
3. **Monitor lower-tail dependence separately by horizon** as a diagnostic and early-warning measure.
4. **Develop an explicit cross-horizon dependence model**, such as a meta-copula, a joint multivariate model for all asset–horizon components, or a dependence-preserving block bootstrap.
5. **Use increases in long-horizon tail dependence**, particularly in SPY–GLD and TLT–GLD, as a trigger for additional stress tests or tighter limits.

This recommendation answers the practical question directly: the risk manager should change the aggregation method and should not interpret a less-negative simulated VaR as evidence of improved protection.

## 12. Limitations and Future Work

The main limitation is the absence of a cross-horizon dependence model. Other limitations are: only three assets are included; transaction costs, rebalancing, and turnover are omitted; the data depend on Yahoo Finance; forward/backward filling can affect returns; dependence is non-stationary; there is no formal inference for horizon differences or bootstrap interval; Christoffersen and formal ES validation are absent; the ES score is simplified; the backtest uses a fixed window; wavelet boundary effects may matter; and no alternative wavelet-family sensitivity analysis is reported.

Future work should first preserve dependence across all asset–horizon components. It should then compare rolling and expanding estimation, stress periods, alternative wavelets, block bootstrap schemes, additional assets, and formal joint VaR/ES validation. Any improvement should be judged on genuinely unseen data, not only on lower in-sample risk estimates.

## 13. Reproducibility and Submission Information

The repository provides the following reproduction path:

```bash
pip install -r requirements.txt
python run_all.py
pytest
```

The pipeline downloads data through `yfinance`, creates processed data under `data/processed/`, writes figures under `outputs/figures/`, tables under `outputs/tables/`, and the report under `report/`. The AI use and responsibility statement is recorded in `AI_DISCLOSURE.md`.

Exact numbers can vary slightly if Yahoo Finance revises historical data or changes download behavior. Reproducibility therefore means reproducible code and methodology, not a guarantee of byte-for-byte identical results across all future downloads.

## 14. Conclusion

The evidence answers the five central questions. The SPY/TLT/GLD portfolio is economically meaningful as a compact growth–duration–macro allocation. Its empirical lower-tail dependence varies across wavelet horizons, especially for SPY–GLD and TLT–GLD. A simple one-horizon model and historical simulation produce substantially more conservative risk estimates than the current Wavelet-Copula aggregation. The proposed model does **not** perform better on unseen data: it records 28 VaR violations against 6.92 expected, while the historical benchmark records 5.

The result is informative model-risk evidence. Tail dependence changes by horizon, but independently simulating the horizons does not preserve crisis co-movement and produces an overly optimistic aggregate VaR and ES. Cross-horizon dependence must be modeled before this approach can be considered for production risk control.

## 15. References

- Acerbi, C., & Székely, B. (2014). Backtesting Expected Shortfall. *Risk*, 27(11), 76–81.
- Christoffersen, P. F. (1998). Evaluating interval forecasts. *International Economic Review*, 39(4), 841–862.
- Daubechies, I. (1992). *Ten Lectures on Wavelets*. SIAM.
- Genest, C., & Favre, A.-C. (2007). Everything you always wanted to know about copula modeling but were afraid to ask. *Journal of Hydrologic Engineering*, 12(4), 347–368.
- Kupiec, P. H. (1995). Techniques for verifying the accuracy of risk measurement models. *The Journal of Derivatives*, 3(2), 73–84.
- McNeil, A. J., & Frey, R. (2000). Estimation of tail-related risk measures for heteroscedastic financial time series: An extreme value approach. *Journal of Empirical Finance*, 7(3–4), 271–300.
- Nelsen, R. B. (2006). *An Introduction to Copulas* (2nd ed.). Springer.
- Percival, D. B., & Walden, A. T. (2000). *Wavelet Methods for Time Series Analysis*. Cambridge University Press.

